﻿using DadJokesProjectAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace DadJokesProjectAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {

        private readonly ILogger<ValuesController> _logger;
        public IConfiguration _configuration { get; }

        public ValuesController(ILogger<ValuesController> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
        }

        [NonAction]
        private HttpRequestMessage GetHttpRequestMessage(string StrUri)
        {
            var request = new HttpRequestMessage
            {
                Method = HttpMethod.Get,
                RequestUri = new Uri(StrUri),
                Headers =
                        {
                            { "X-RapidAPI-Key", _configuration.GetValue<string>("X-RapidAPI-Key") },
                            { "X-RapidAPI-Host", _configuration.GetValue<string>("X-RapidAPI-Host") },
                        },
            };
            return request;
        }

        [HttpGet]
        [Route("GetRandomJoke")]
        [ProducesResponseType(typeof(Root), 200)]
        public async Task<IActionResult> GetRandomJoke()
        {
            var AcceptType = HttpContext.Request.Headers["Accept"];
            HttpContext.Response.ContentType = AcceptType;

            Root responseroot = null;
            var client = new HttpClient();
            string strUrl = "https://dad-jokes.p.rapidapi.com/random/joke";            
            using (var response = await client.SendAsync(GetHttpRequestMessage(strUrl)))
            {
                response.EnsureSuccessStatusCode();
                var result = response.Content.ReadAsStringAsync().Result;
                responseroot = JsonConvert.DeserializeObject<Root>(result);
                if (responseroot != null)
                {
                    return Ok(responseroot);
                }
                else
                {
                    throw new Exception("Details not found.");
                }
            }
        }

        [HttpGet]
        [Route("JokeCount/{count}")]
        [ProducesResponseType(typeof(Root), 200)]
        public async Task<IActionResult> GetJokeCount(int count)
        {
            if (count > 5)
            {
                var message = string.Format("Maximum count limit is 5 only.");
                throw new Exception(message);
            }
            Root responseroot = new Root();
            var client = new HttpClient();
            string strUrl = "https://dad-jokes.p.rapidapi.com/random/joke?count=" + count;
            using (var response = await client.SendAsync(GetHttpRequestMessage(strUrl)))
            {
                response.EnsureSuccessStatusCode();
                var result = response.Content.ReadAsStringAsync().Result;
                responseroot = JsonConvert.DeserializeObject<Root>(result);
            }
            return Ok(responseroot);
        }
    }
}
