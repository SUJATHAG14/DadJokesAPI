﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DadJokesProjectAPI.Models
{
    public class DadJokeModel
    {
        public string _id { set; get; }
        public string type { set; get; }
        public string setup { set; get; }
        public string punchline { set; get; }
    }

    public class Author
    {
        public string name { get; set; }
        public object id { get; set; }
    }

    public class Body
    {
        public string _id { get; set; }
        public string setup { get; set; }
        public string punchline { get; set; }
        public string type { get; set; }
        public List<object> likes { get; set; }
        public Author author { get; set; }
        public bool approved { get; set; }
        public int date { get; set; }
        public bool NSFW { get; set; }
        public string shareableLink { get; set; }
    }

    public class Root
    {
        public bool success { get; set; }
        public Body[] body { get; set; }
    }


}
